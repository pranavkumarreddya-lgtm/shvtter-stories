import { motion } from 'motion/react';
import { Shield, Hammer, Feather, Award } from 'lucide-react';
import { gearInventory } from '../data';

export default function About() {
  const highlights = [
    {
      icon: Feather,
      title: 'Minimalist Focus',
      desc: 'Removing ambient visual clutter to prioritize the emotional weight and raw structure of the focal subject.',
    },
    {
      icon: Hammer,
      title: 'Surgical Precision',
      desc: 'Meticulous control over lighting setups, exposure calculations, and lens calibrations to ensure printing grade fidelity.',
    },
    {
      icon: Shield,
      title: 'Ethical Candid',
      desc: 'Operating with transparency and absolute respect for human dignity across all street and cultural photography projects.',
    },
    {
      icon: Award,
      title: 'Fine-Art Quality',
      desc: 'Crafting high-resolution museum grade prints with precise tonal ranges, deep contrast profiles, and physical durability.',
    }
  ];

  return (
    <section id="about" className="py-24 px-6 md:px-12 lg:px-24 bg-[#050505] border-t border-neutral-900">
      <div className="max-w-7xl mx-auto">
        {/* About Hero Header */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start mb-20">
          <div className="lg:col-span-5">
            <span className="font-mono text-[9px] tracking-[0.35em] text-gold-400 font-semibold uppercase">
              BIOGRAPHY & PHILOSOPHY
            </span>
            <h2 className="font-serif text-3xl md:text-5xl font-light text-white mt-3 leading-tight">
              Honoring the Silent Moments
            </h2>
          </div>
          <div className="lg:col-span-7 font-sans font-light text-neutral-400 space-y-6 text-[13px] md:text-[14px] leading-relaxed">
            <p>
              I am a visual storyteller specializing in travel, portraiture, and high-precision commercial photography. For over a decade, I have traveled across continents—from the sub-zero arctic fjords of Norway to the neon-drenched alleys of Tokyo—seeking the unspoken narratives that lie within our environments.
            </p>
            <p>
              My approach is fundamentally minimalist. By omitting excess noise, background animations, or superficial embellishments, I seek to let the true story of the frame breathe. It is not simply about capturing what is there; it is about conveying the heavy atmosphere, the sudden shifts in light, and the raw humanity of the instant.
            </p>
            <p className="border-l-2 border-gold-500 pl-4 text-gold-200 italic font-serif text-base font-normal my-6">
              "A photograph is not an active creation; it is a quiet agreement between light, time, and observation."
            </p>
          </div>
        </div>

        {/* Highlight Pillars */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-24" id="about-highlights-grid">
          {highlights.map((hl, idx) => (
            <div 
              key={idx} 
              className="p-6 bg-neutral-950 border border-neutral-900 hover:border-neutral-800 transition-colors duration-300 flex flex-col justify-between"
            >
              <div>
                <div className="w-10 h-10 rounded-full border border-neutral-800 flex items-center justify-center text-gold-400 mb-6">
                  <hl.icon className="w-4 h-4" />
                </div>
                <h3 className="font-serif text-lg font-normal text-white mb-3">{hl.title}</h3>
                <p className="font-sans text-xs text-neutral-400 leading-relaxed font-light">{hl.desc}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Technical Gear Bag Section (Fully typography based, premium feel) */}
        <div className="border-t border-neutral-900 pt-16" id="about-gear-bag">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
            <div>
              <span className="font-mono text-[9px] tracking-[0.35em] text-gold-400 font-semibold uppercase">
                THE HARDWARE
              </span>
              <h3 className="font-serif text-2xl md:text-3xl font-light text-white mt-2">
                The Gear Bag
              </h3>
            </div>
            <p className="font-sans text-xs text-neutral-500 max-w-xs mt-4 md:mt-0 font-light leading-relaxed">
              Meticulously maintained and selected professional tools chosen to extract maximum technical fidelity.
            </p>
          </div>

          <div className="space-y-4">
            {/* Categorized gear items list */}
            {['Camera Bodies', 'Prime Lenses', 'Zoom Lenses'].map((catName) => {
              const catGear = gearInventory.filter(item => item.category === catName);
              return (
                <div 
                  key={catName} 
                  className="grid grid-cols-1 md:grid-cols-12 gap-4 py-6 border-b border-neutral-900"
                >
                  <div className="md:col-span-3">
                    <span className="font-mono text-[10px] tracking-widest text-neutral-500 uppercase font-bold">
                      {catName}
                    </span>
                  </div>
                  <div className="md:col-span-9 space-y-4">
                    {catGear.map((gear, idx) => (
                      <div key={idx} className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <span className="font-sans text-[13px] font-medium text-white">{gear.model}</span>
                        <span className="font-sans text-[11px] text-neutral-400 font-light max-w-md sm:text-right">
                          {gear.purpose}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
