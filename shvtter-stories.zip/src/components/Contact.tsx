import { useState, FormEvent, ChangeEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mail, Phone, MapPin, Send, CheckCircle2, RefreshCw } from 'lucide-react';

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    category: 'PORTRAIT',
    budget: '2500-5000',
    message: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [referenceId, setReferenceId] = useState('');

  const handleInputChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) {
      return;
    }

    setIsSubmitting(true);

    // Simulate submission delay
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
      // Generate a unique transaction/booking reference ID
      const randHex = Math.random().toString(16).substring(2, 8).toUpperCase();
      setReferenceId(`SST-${randHex}`);
    }, 1500);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      email: '',
      category: 'PORTRAIT',
      budget: '2500-5000',
      message: ''
    });
    setIsSubmitted(false);
  };

  return (
    <section id="contact" className="py-24 px-6 md:px-12 lg:px-24 bg-[#050505] border-t border-neutral-900">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-start">
          {/* Left Column: Direct Inquiries */}
          <div className="lg:col-span-5 space-y-12">
            <div>
              <span className="font-mono text-[9px] tracking-[0.35em] text-gold-400 font-semibold uppercase">
                INQUIRIES & COMMISSIONS
              </span>
              <h2 className="font-serif text-3xl md:text-5xl font-light text-white mt-3 leading-tight">
                Let's Frame a Story
              </h2>
              <p className="font-sans text-xs text-neutral-400 font-light mt-6 leading-relaxed max-w-sm">
                Available for international editorial commissions, premium commercial portfolios, and customized fine-art prints.
              </p>
            </div>

            {/* Direct Coordinates card lists */}
            <div className="space-y-6 pt-4 border-t border-neutral-900/80">
              <div className="flex items-start space-x-4">
                <div className="w-10 h-10 rounded-full border border-neutral-800 flex items-center justify-center text-gold-400 mt-1 flex-shrink-0">
                  <Mail className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-mono text-[9px] tracking-widest text-neutral-500 uppercase font-bold">EMAIL INQUIRIES</span>
                  <a 
                    href="mailto:contact@shvtterstories.com" 
                    className="block font-sans text-sm text-white hover:text-gold-400 transition-colors duration-200 mt-1"
                  >
                    contact@shvtterstories.com
                  </a>
                  <span className="text-[10px] text-neutral-500 font-light">Response within 24 business hours</span>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-10 h-10 rounded-full border border-neutral-800 flex items-center justify-center text-gold-400 mt-1 flex-shrink-0">
                  <Phone className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-mono text-[9px] tracking-widest text-neutral-500 uppercase font-bold">DIRECT TELEPHONE</span>
                  <a 
                    href="tel:+12125558920" 
                    className="block font-sans text-sm text-white hover:text-gold-400 transition-colors duration-200 mt-1"
                  >
                    +1 (212) 555-8920
                  </a>
                  <span className="text-[10px] text-neutral-500 font-light">Mon - Fri • 9:00 AM - 6:00 PM EST</span>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-10 h-10 rounded-full border border-neutral-800 flex items-center justify-center text-gold-400 mt-1 flex-shrink-0">
                  <MapPin className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-mono text-[9px] tracking-widest text-neutral-500 uppercase font-bold">STUDIO LOCATION</span>
                  <p className="font-sans text-sm text-white mt-1">
                    422 Greenwich St, Tribeca
                  </p>
                  <span className="text-[10px] text-neutral-500 font-light">New York, NY 10013 (By Appointment Only)</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Custom Interactive Form */}
          <div className="lg:col-span-7 bg-neutral-950 border border-neutral-900 rounded-xl p-8 relative">
            <AnimatePresence mode="wait">
              {!isSubmitted ? (
                <motion.form 
                  key="contact-form"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  onSubmit={handleSubmit} 
                  className="space-y-6"
                >
                  <h3 className="font-serif text-xl text-white font-normal mb-2 border-b border-neutral-900 pb-3">
                    Booking Request Form
                  </h3>

                  {/* Name field */}
                  <div className="space-y-2">
                    <label className="font-mono text-[10px] tracking-widest text-neutral-400 uppercase font-semibold">
                      Your Full Name *
                    </label>
                    <input
                      required
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      placeholder="e.g. Alexander Mercer"
                      className="w-full bg-[#0d0d0d] border border-neutral-800 focus:border-gold-500 focus:outline-none rounded-md px-4 py-3 font-sans text-xs text-white transition-colors duration-300"
                    />
                  </div>

                  {/* Email field */}
                  <div className="space-y-2">
                    <label className="font-mono text-[10px] tracking-widest text-neutral-400 uppercase font-semibold">
                      Email Address *
                    </label>
                    <input
                      required
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      placeholder="e.g. alex@example.com"
                      className="w-full bg-[#0d0d0d] border border-neutral-800 focus:border-gold-500 focus:outline-none rounded-md px-4 py-3 font-sans text-xs text-white transition-colors duration-300"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    {/* Category selection */}
                    <div className="space-y-2">
                      <label className="font-mono text-[10px] tracking-widest text-neutral-400 uppercase font-semibold">
                        Commission Category
                      </label>
                      <select
                        name="category"
                        value={formData.category}
                        onChange={handleInputChange}
                        className="w-full bg-[#0d0d0d] border border-neutral-800 focus:border-gold-500 focus:outline-none rounded-md px-4 py-3 font-sans text-xs text-neutral-400 focus:text-white transition-all duration-300 cursor-pointer"
                      >
                        <option value="PORTRAIT">PORTRAIT SESSION</option>
                        <option value="LANDSCAPE">LANDSCAPE COMMISSION</option>
                        <option value="WILDLIFE">WILDLIFE / OUTDOORS</option>
                        <option value="TRAVEL">TRAVEL EDITORIAL</option>
                        <option value="STREET">STREET / DOCUMENTARY</option>
                        <option value="COMMERCIAL">COMMERCIAL CAMPAIGN</option>
                      </select>
                    </div>

                    {/* Budget selection */}
                    <div className="space-y-2">
                      <label className="font-mono text-[10px] tracking-widest text-neutral-400 uppercase font-semibold">
                        Estimated Budget (USD)
                      </label>
                      <select
                        name="budget"
                        value={formData.budget}
                        onChange={handleInputChange}
                        className="w-full bg-[#0d0d0d] border border-neutral-800 focus:border-gold-500 focus:outline-none rounded-md px-4 py-3 font-sans text-xs text-neutral-400 focus:text-white transition-all duration-300 cursor-pointer"
                      >
                        <option value="1500-2500">$1,500 - $2,500</option>
                        <option value="2500-5000">$2,500 - $5,000</option>
                        <option value="5000-10000">$5,000 - $10,000</option>
                        <option value="10000+">$10,000+ (Custom campaign)</option>
                      </select>
                    </div>
                  </div>

                  {/* Message narrative */}
                  <div className="space-y-2">
                    <label className="font-mono text-[10px] tracking-widest text-neutral-400 uppercase font-semibold">
                      Project Narrative & Vision *
                    </label>
                    <textarea
                      required
                      name="message"
                      rows={5}
                      value={formData.message}
                      onChange={handleInputChange}
                      placeholder="Describe your desired project goals, preferred locations, timelines, and visual expectations..."
                      className="w-full bg-[#0d0d0d] border border-neutral-800 focus:border-gold-500 focus:outline-none rounded-md px-4 py-3 font-sans text-xs text-white transition-colors duration-300 resize-none"
                    />
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-4 bg-[#9c7a55] hover:bg-[#a97c55] disabled:bg-neutral-800 text-white font-sans text-[11px] font-semibold tracking-[0.25em] uppercase transition-all duration-300 shadow-md hover:scale-[1.01] flex items-center justify-center gap-2 select-none cursor-pointer"
                    id="submit-contact-btn"
                  >
                    {isSubmitting ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin text-neutral-400" />
                        SUBMITTING DISPATCH...
                      </>
                    ) : (
                      <>
                        <Send className="w-3.5 h-3.5 text-white/80" />
                        TRANSMIT SECURE BRIEF
                      </>
                    )}
                  </button>
                </motion.form>
              ) : (
                <motion.div 
                  key="contact-success"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0 }}
                  className="py-12 text-center space-y-6 flex flex-col items-center justify-center"
                >
                  <div className="w-16 h-16 rounded-full bg-gold-950/20 border border-gold-800 flex items-center justify-center text-gold-400">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  
                  <div className="space-y-2">
                    <h3 className="font-serif text-2xl text-white font-normal">Brief Transmission Secured</h3>
                    <p className="font-sans text-xs text-neutral-400 font-light max-w-sm mx-auto leading-relaxed">
                      Thank you, <span className="text-white font-medium">{formData.name}</span>. Your creative portfolio inquiry has been successfully serialized and routed to our central inbox.
                    </p>
                  </div>

                  {/* Fictional ticket details */}
                  <div className="border border-neutral-900 bg-[#0d0d0d] p-5 rounded-lg max-w-md w-full text-left font-mono text-[10px] text-neutral-400 space-y-2">
                    <div className="flex justify-between border-b border-neutral-900 pb-2 text-[11px] text-gold-400 font-bold">
                      <span>REFERENCE TICKET</span>
                      <span>{referenceId}</span>
                    </div>
                    <div className="flex justify-between pt-1">
                      <span>EMAIL TARGET:</span>
                      <span className="text-white">{formData.email}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>COMMISSION:</span>
                      <span className="text-white">{formData.category} SESSION</span>
                    </div>
                    <div className="flex justify-between">
                      <span>BUDGET RANGE:</span>
                      <span className="text-white">${formData.budget} USD</span>
                    </div>
                    <div className="flex justify-between pt-2 border-t border-neutral-900 text-neutral-500">
                      <span>TIMESTAMP:</span>
                      <span>{new Date().toLocaleString()}</span>
                    </div>
                  </div>

                  <button
                    onClick={resetForm}
                    className="mt-6 px-6 py-2.5 border border-neutral-800 hover:border-neutral-700 text-neutral-400 hover:text-white font-sans text-[10px] tracking-[0.2em] uppercase font-semibold transition-colors"
                  >
                    SUBMIT NEW BRIEF
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
}
